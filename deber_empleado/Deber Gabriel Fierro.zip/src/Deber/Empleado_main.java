
package Deber;

public class Empleado_main {

    public static void main(String[] args) {
        Empleado emp = new Empleado();
        
        emp.mayor_salario();
    }
}
