package com.example.user.dway_audio;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;


public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button boton = (Button) findViewById(R.id.ingresar);
        boton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String usuario = ((EditText) findViewById(R.id.nomuser)).getText().toString();
                String email = ((EditText) findViewById(R.id.emailuser)).getText().toString();
                String password = ((EditText) findViewById(R.id.passuser)).getText().toString();
                if (usuario.equals("Gabriel") && email.equals("gabrielandro12@hotmail.com") && password.equals("proyecto")){
                    Intent nuevoformulario = new Intent(MainActivity.this,Secundario.class);
                    startActivity(nuevoformulario);

                }else {
                    Toast.makeText(getApplicationContext(),"Usuario Incorrecto",Toast.LENGTH_LONG).show();

                }
            }
        });
    }
}
